# Waste Czar Desk — UI Kit

Desktop-primary. Reframes the DataHacks-2026 codebase as the Czar's office: oak desk, brass-framed monitor showing the isometric town, HUD strip as a brass plaque, and a paper dossier as the scenario console.

## Components

- `Logo` — wordmark + badge (with `invert` for dark desk use)
- `Seal` — circular wax-seal mark; scale via `size` prop
- `HUD` — five-metric strip (glass over desk)
- `Dossier` — paper card, folder tab, punch holes, stamp slot, choice buttons with delta summaries
- `Stamp` — `approved | denied | pending | catastrophe`, animates in
- `IsoMap` — simplified iso grid; pristine↔polluted sprite swap driven by `ecoHealth` prop
- `ActionCard` — endgame educational paper

## Interactions

- Choose a dossier option → approved/denied stamp appears, metrics animate, dossier advances to next `NextNodeID`.
- `New Term` resets metrics to 75 and returns to `ROOT_001`.
- `Landfill` building tone swaps at `infraLoad > 65` (warning) / `> 80` (danger + shake).
- Map palette flips when `ecoHealth < 35`.
