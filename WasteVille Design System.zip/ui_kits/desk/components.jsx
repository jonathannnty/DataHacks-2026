// Components for Waste Czar's Desk (desktop UI kit).
// Shared <script type="text/babel" src="./components.jsx"> module.
// All components registered on window at end of file.

const { useState, useEffect, useMemo, useRef } = React;

// ---- tokens -----------------------------------------------------------
const C = {
  oak900: '#3b2a1a', oak800: '#4a341f', oak700: '#6b4a2b',
  oak500: '#8d6a3e', oak300: '#c9a66b',
  paper50: '#f5ecd7', paper100: '#ede1c4', paper200: '#d9c99e',
  ink900: '#1a1410', ink700: '#3b2e24',
  wax: '#a8242b', waxDark: '#7a161c',
  emerald: '#10b981', emeraldDark: '#047857',
  slate: '#334155', slateDark: '#0f172a', slateLight: '#64748b',
  warning: '#f59e0b', danger: '#ef4444',
};

// ---- Logo / Seal ------------------------------------------------------
function Logo({ invert = false }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{
        width: 38, height: 38, borderRadius: 8,
        background: invert ? '#fff' : C.emeraldDark, color: invert ? C.emeraldDark : '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: "'Special Elite'", fontSize: 20,
        boxShadow: 'inset 0 -2px 0 rgba(0,0,0,.2)',
      }}>W</div>
      <div>
        <div style={{ fontFamily: "'Special Elite'", fontSize: 22, lineHeight: 1, color: invert ? '#fff' : C.ink900 }}>
          <i style={{ fontStyle: 'normal', color: invert ? '#34d399' : C.emeraldDark }}>Waste</i>Ville
        </div>
        <div style={{ fontFamily: 'Inter', fontSize: 10, letterSpacing: '.18em', textTransform: 'uppercase', color: invert ? '#94a3b8' : C.oak500, marginTop: 2 }}>
          Office of the Waste Czar
        </div>
      </div>
    </div>
  );
}

function Seal({ size = 110 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      border: `3px double ${C.wax}`, color: C.wax,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      textAlign: 'center', fontFamily: "'Special Elite'",
      fontSize: size * 0.08, letterSpacing: '.15em', textTransform: 'uppercase',
      lineHeight: 1.3, background: 'rgba(168,36,43,.05)',
      transform: 'rotate(-4deg)', padding: size * 0.1,
    }}>
      <div>
        <div style={{ fontSize: size * 0.11, marginBottom: 2 }}>Office of the</div>
        <div style={{ fontSize: size * 0.16, fontWeight: 700 }}>Waste Czar</div>
        <div style={{ fontSize: size * 0.075, marginTop: 3, opacity: .7 }}>WasteVille · MMXXVI</div>
      </div>
    </div>
  );
}

// ---- Metric bar -------------------------------------------------------
const METRICS = [
  { key: 'Treasury', label: 'Treasury', glyph: '$', inverted: false },
  { key: 'EcoHealth', label: 'Eco-Health', glyph: '🌿', inverted: false },
  { key: 'PublicSentiment', label: 'Public Sentiment', glyph: '🙂', inverted: false },
  { key: 'InfrastructureLoad', label: 'Infra-Load', glyph: '⚙', inverted: true },
  { key: 'SocialEquity', label: 'Social Equity', glyph: '⚖', inverted: false },
];
function barColor(value, inverted) {
  const v = inverted ? 100 - value : value;
  if (v < 25) return C.danger;
  if (v < 50) return C.warning;
  if (v < 75) return C.emerald;
  return C.emeraldDark;
}

function HUD({ metrics, deltas = {} }) {
  return (
    <section style={{
      display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 12,
      background: 'rgba(255,255,255,.78)', backdropFilter: 'blur(6px)',
      padding: 14, borderRadius: 10,
      boxShadow: '0 1px 0 rgba(0,0,0,.05), 0 10px 24px -12px rgba(59,42,26,.4)',
      border: '1px solid rgba(107,74,43,.15)',
    }}>
      {METRICS.map(m => {
        const v = metrics[m.key];
        const d = deltas[m.key];
        return (
          <div key={m.key} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontFamily: 'Inter', fontSize: 11, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', color: C.slate }}>
              <span><span style={{ marginRight: 4 }}>{m.glyph}</span>{m.label}</span>
              <span style={{ fontFamily: "'JetBrains Mono'", color: C.slateDark, fontVariantNumeric: 'tabular-nums' }}>
                {Math.round(v)}
                {d !== undefined && d !== 0 && (
                  <span style={{ color: d > 0 ? C.emeraldDark : C.danger, marginLeft: 4, fontSize: 10 }}>
                    {d > 0 ? '▲' : '▼'}{Math.abs(d)}
                  </span>
                )}
              </span>
            </div>
            <div style={{ height: 8, background: '#e2e8f0', borderRadius: 9999, overflow: 'hidden' }}>
              <div style={{
                height: '100%', width: `${Math.max(0, Math.min(100, v))}%`,
                background: barColor(v, m.inverted), borderRadius: 9999,
                transition: 'width .45s cubic-bezier(.2,.8,.2,1), background .3s',
              }} />
            </div>
          </div>
        );
      })}
    </section>
  );
}

// ---- Dossier card -----------------------------------------------------
function Dossier({ node, onChoose, stamp = null, shake = false }) {
  return (
    <div className="dossier-stack" style={{ position:'relative', paddingTop:14, paddingBottom:28 }}>
      {/* Manila envelope — sits at the bottom of the pile */}
      <div aria-hidden="true" style={{
        position:'absolute', left:-6, right:-6, bottom:-10, height:'72%',
        background:'linear-gradient(180deg, #e4c27a 0%, #d0a858 60%, #b98d3d 100%)',
        borderRadius:'4px 4px 10px 10px',
        boxShadow:'0 1px 0 rgba(0,0,0,.1), 0 14px 30px -10px rgba(59,42,26,.5), inset 0 -3px 0 rgba(0,0,0,.15)',
        border:'1px solid rgba(107,74,43,.45)',
        transform:'rotate(-.8deg)',
        zIndex:0,
      }}>
        {/* envelope flap */}
        <div style={{
          position:'absolute', left:0, right:0, top:0, height:'40%',
          background:'linear-gradient(180deg, #d0a858 0%, #c99d4a 100%)',
          clipPath:'polygon(0 0, 100% 0, 85% 60%, 50% 100%, 15% 60%)',
          borderBottom:'1px dashed rgba(107,74,43,.4)',
          opacity:.8,
        }}/>
        {/* string-and-button closure */}
        <div style={{position:'absolute', left:'50%', top:'28%', transform:'translateX(-50%)', width:14, height:14, borderRadius:'50%',
          background:'radial-gradient(circle at 35% 35%, #7a5532, #3b2a1a)',
          boxShadow:'0 0 0 2px rgba(107,74,43,.3), 0 2px 2px rgba(0,0,0,.4)'}}/>
        {/* diagonal red string */}
        <svg style={{position:'absolute',inset:0,width:'100%',height:'100%',overflow:'visible',pointerEvents:'none'}}>
          <path d="M 50% 28% Q 20% 55%, 8 85%" stroke="#a8242b" strokeWidth="1.3" fill="none" strokeDasharray="4 3" opacity=".8"/>
          <path d="M 50% 28% Q 80% 55%, 96% 85%" stroke="#a8242b" strokeWidth="1.3" fill="none" strokeDasharray="4 3" opacity=".8"/>
        </svg>
        {/* printed label on the envelope */}
        <div style={{position:'absolute', left:14, bottom:10, fontFamily:"'Special Elite'", fontSize:10, letterSpacing:'.2em', color:C.ink700, opacity:.75, textTransform:'uppercase'}}>
          Case File · № {node.NodeID}
        </div>
        <div style={{position:'absolute', right:14, bottom:10, fontFamily:"'JetBrains Mono'", fontSize:9, color:C.ink700, opacity:.6}}>
          4 of 12 pending
        </div>
      </div>

      {/* Stack of pending cards behind the active one — kept entirely below the
          top edge of the active card so the "Incoming Dossier" caption is never
          covered. */}
      <div aria-hidden="true" style={{
        position:'absolute', left:10, right:-12, top:26, bottom:18,
        background:C.paper100,
        backgroundImage:'repeating-linear-gradient(to bottom, transparent 0 23px, rgba(107,74,43,.08) 23px 24px)',
        borderRadius:10, border:'1px solid rgba(107,74,43,.25)',
        boxShadow:'0 8px 20px -10px rgba(59,42,26,.4)',
        transform:'rotate(1.8deg)', transformOrigin:'left top', zIndex:1,
      }}/>
      <div aria-hidden="true" style={{
        position:'absolute', left:-8, right:12, top:20, bottom:14,
        background:'#fff8e8',
        backgroundImage:'repeating-linear-gradient(to bottom, transparent 0 23px, rgba(107,74,43,.07) 23px 24px)',
        borderRadius:10, border:'1px solid rgba(107,74,43,.22)',
        boxShadow:'0 6px 16px -8px rgba(59,42,26,.35)',
        transform:'rotate(-1.2deg)', transformOrigin:'right top', zIndex:2,
      }}/>

      {/* Active dossier card (top of pile) */}
      <section style={{
        position: 'relative', zIndex:3,
        background: C.paper50,
        backgroundImage: 'repeating-linear-gradient(to bottom, transparent 0 23px, rgba(107,74,43,.09) 23px 24px)',
        borderRadius: 12, padding: '22px 22px 18px',
        boxShadow: '0 2px 0 rgba(0,0,0,.05), 0 18px 40px -16px rgba(59,42,26,.55)',
        border: '1px solid rgba(107,74,43,.2)',
        animation: shake ? 'czarShake .5s ease-in-out 3' : undefined,
      }}>
      {/* folder tab */}
      <div style={{
        position: 'absolute', top: -12, left: 18,
        background: C.paper200, padding: '5px 14px', borderRadius: '5px 5px 0 0',
        fontFamily: 'Inter', fontSize: 10, fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase',
        color: C.ink700, border: '1px solid rgba(107,74,43,.28)', borderBottom: 0,
      }}>№ {node.NodeID} · Memo</div>

      {/* punch holes */}
      <div style={{ position: 'absolute', top: 30, left: 6, display: 'flex', flexDirection: 'column', gap: 30 }}>
        {[0,1,2].map(i => <div key={i} style={{ width: 10, height: 10, borderRadius: '50%', background: C.oak700, boxShadow: 'inset 0 1px 2px rgba(0,0,0,.4)' }} />)}
      </div>

      {stamp && <Stamp kind={stamp} />}

      <div style={{ marginLeft: 18 }}>
        <div style={{ fontFamily: "'JetBrains Mono'", fontSize: 10.5, color: C.oak500, letterSpacing: '.05em', marginBottom: 4 }}>
          OFFICE OF THE WASTE CZAR · FY 2026 Q2
        </div>
        <h2 style={{ fontFamily: "'Special Elite'", fontSize: 26, lineHeight: 1.2, color: C.ink900, margin: '0 0 8px' }}>
          {node.Title}
        </h2>
        <p style={{ fontFamily: "'Libre Caslon Text', Georgia, serif", fontSize: 15, lineHeight: 1.55, color: C.ink900, margin: '0 0 14px' }}>
          {node.Context}
        </p>

        <div style={{ fontFamily: 'Inter', fontSize: 10, fontWeight: 700, letterSpacing: '.12em', textTransform: 'uppercase', color: C.oak500, marginBottom: 6 }}>
          Options for the Czar
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
          {node.Choices.map((c, i) => (
            <button key={i} onClick={() => onChoose?.(i)} className="czar-choice" style={{
              display: 'flex', gap: 10, padding: '11px 14px',
              background: '#fff9ea', border: '1px solid rgba(107,74,43,.22)', borderRadius: 8,
              fontFamily: 'Inter', fontSize: 13.5, fontWeight: 600, color: C.ink900,
              alignItems: 'center', textAlign: 'left', cursor: 'pointer', transition: 'all .18s',
            }}>
              <span style={{
                width: 22, height: 22, borderRadius: 999, background: C.emerald, color: '#fff',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 800, flex: '0 0 auto',
              }}>{String.fromCharCode(65 + i)}</span>
              <span style={{ flex: 1 }}>{c.ChoiceText}</span>
              <span style={{ fontFamily: "'JetBrains Mono'", fontSize: 10, color: C.slateLight }}>
                {deltaSummary(c.MetricModifiers)}
              </span>
            </button>
          ))}
          {node.Choices.length === 0 && (
            <div style={{ padding: '12px 14px', background: 'rgba(107,74,43,.08)', border: '1px dashed rgba(107,74,43,.3)', borderRadius: 8, fontFamily: "'Libre Caslon Text', serif", fontSize: 13, color: C.ink700 }}>
              Scenario concluded. Open the Action Center for real-world context.
            </div>
          )}
        </div>
      </div>
      </section>
    </div>
  );
}

function deltaSummary(mods) {
  if (!mods) return '';
  const biggest = Object.entries(mods).sort((a,b)=>Math.abs(b[1])-Math.abs(a[1]))[0];
  if (!biggest) return '';
  const sign = biggest[1] > 0 ? '+' : '';
  const short = { Treasury:'$', EcoHealth:'🌿', PublicSentiment:'🙂', InfrastructureLoad:'⚙', SocialEquity:'⚖' }[biggest[0]] || '';
  return `${short}${sign}${biggest[1]}`;
}

// ---- Stamp ------------------------------------------------------------
function Stamp({ kind }) {
  const map = {
    approved: { text: 'Approved', color: C.emeraldDark },
    denied: { text: 'Denied', color: C.wax },
    pending: { text: 'Pending', color: C.slate },
    catastrophe: { text: 'Catastrophe', color: C.wax },
  };
  const s = map[kind] || map.pending;
  return (
    <div style={{
      position: 'absolute', right: 18, top: 14,
      border: `3px double ${s.color}`, color: s.color,
      padding: '5px 12px', borderRadius: 4,
      fontFamily: "'Special Elite'", fontSize: 13, letterSpacing: '.15em', textTransform: 'uppercase',
      transform: `rotate(${kind === 'catastrophe' ? 5 : -6}deg)`,
      opacity: .9, background: 'rgba(255,255,255,.35)',
      animation: 'czarStamp .4s cubic-bezier(.3,1.5,.5,1)',
    }}>{s.text}</div>
  );
}

// ---- Isometric map (simplified) ---------------------------------------
function IsoMap({ ecoHealth, infraLoad }) {
  const polluted = ecoHealth < 35;
  const GRID = 8;
  const tiles = [];
  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const isRoad = (x === 3) || (y === 3);
      const isWater = (x === 0 || x === 7);
      let cls = polluted ? 'p' : 'g';
      if (isRoad) cls = polluted ? 'lr' : 'r';
      if (isWater) cls = polluted ? 'tw' : 'w';
      tiles.push(<div key={`${x}-${y}`} className={`iso-tile ${cls}`} style={{ left: x * 64, top: y * 32 }} />);
    }
  }
  const buildings = [
    { key: 'city_hall', x: 3, y: 3, label: 'City Hall', tone: 'default' },
    { key: 'landfill', x: 6, y: 1, label: 'Landfill', tone: infraLoad > 80 ? 'danger' : infraLoad > 65 ? 'warning' : 'default' },
    { key: 'mrf', x: 1, y: 5, label: 'MRF', tone: ecoHealth > 65 ? 'success' : 'default' },
    { key: 'industrial', x: 5, y: 5, label: 'Industrial', tone: 'default' },
    { key: 'park', x: 1, y: 1, label: 'Park', tone: polluted ? 'warning' : 'success' },
    { key: 'residential', x: 5, y: 2, label: 'Residential', tone: 'default' },
  ];
  return (
    <div className="iso-scene">
      <div className="iso-grid" style={{ width: GRID * 64, height: GRID * 32 }}>
        {tiles}
        {buildings.map(b => (
          <div key={b.key} className="iso-tile r" style={{ left: b.x * 64, top: b.y * 32 }}>
            <div className="iso-building-wrap">
              <span className={`iso-building tone-${b.tone}`}>{b.label}</span>
            </div>
          </div>
        ))}
        {/* blobs */}
        {[[2,2],[4,1],[2,6],[5,4]].map(([x,y],i) => (
          <div key={i} className="iso-citizen" style={{ left: x*64+16, top: y*32+8 }}>
            <div className="iso-building-wrap"><div className={`blob ${ecoHealth > 55 ? 'happy' : ecoHealth < 30 ? 'upset' : 'neutral'}`} /></div>
          </div>
        ))}
      </div>
      <div className="iso-screen-overlay" />
    </div>
  );
}

// ---- Action Center card -----------------------------------------------
function ActionCard({ card }) {
  if (!card) return null;
  return (
    <article style={{
      background: C.paper50,
      backgroundImage: 'repeating-linear-gradient(to bottom, transparent 0 23px, rgba(107,74,43,.08) 23px 24px)',
      borderRadius: 12, padding: 22, border: '1px solid rgba(107,74,43,.2)',
      boxShadow: '0 2px 0 rgba(0,0,0,.05), 0 14px 30px -14px rgba(59,42,26,.5)',
    }}>
      <div style={{ fontFamily: "'JetBrains Mono'", fontSize: 10.5, color: C.oak500, letterSpacing: '.06em' }}>
        SCENARIO № {card.nodeId}
      </div>
      <h3 style={{ fontFamily: "'Special Elite'", fontSize: 22, margin: '4px 0 14px', color: C.emeraldDark }}>{card.title}</h3>

      <div style={{ marginBottom: 12 }}>
        <div className="caps-label">Real-world context</div>
        <p style={{ fontFamily: "'Libre Caslon Text', serif", fontSize: 14, color: C.ink900, margin: 0 }}>{card.realWorld}</p>
      </div>
      <div style={{ marginBottom: 12 }}>
        <div className="caps-label">Why it matters</div>
        <p style={{ fontFamily: "'Libre Caslon Text', serif", fontSize: 14, color: C.ink900, margin: 0 }}>{card.why}</p>
      </div>
      <div>
        <div className="caps-label">Practical checklist</div>
        <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 6 }}>
          {card.checklist.map((t, i) => (
            <li key={i} style={{ display: 'flex', gap: 10, padding: '8px 10px', background: '#fff9ea', border: '1px solid rgba(107,74,43,.2)', borderRadius: 6, fontFamily: "'Libre Caslon Text', serif", fontSize: 14, alignItems: 'flex-start' }}>
              <input type="checkbox" style={{ accentColor: C.emerald, marginTop: 3 }} />
              <span>{t}</span>
            </li>
          ))}
        </ul>
      </div>
    </article>
  );
}

Object.assign(window, { Logo, Seal, HUD, Dossier, Stamp, IsoMap, ActionCard, METRICS, C });
