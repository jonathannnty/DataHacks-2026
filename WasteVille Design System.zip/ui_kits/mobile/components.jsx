const { useState, useRef } = React;
const C = {
  oak700:'#6b4a2b', oak500:'#8d6a3e', paper50:'#f5ecd7', paper100:'#ede1c4', paper200:'#d9c99e',
  ink900:'#1a1410', ink700:'#3b2e24', wax:'#a8242b',
  emerald:'#10b981', emeraldDark:'#047857',
  slate:'#334155', slateDark:'#0f172a', slateLight:'#64748b',
  warning:'#f59e0b', danger:'#ef4444',
};

function MiniHUD({ metrics }) {
  const rows = [
    { k:'Treasury', g:'$', inv:false },
    { k:'EcoHealth', g:'🌿', inv:false },
    { k:'PublicSentiment', g:'🙂', inv:false },
    { k:'InfrastructureLoad', g:'⚙', inv:true },
    { k:'SocialEquity', g:'⚖', inv:false },
  ];
  const color = (v, inv) => { const n = inv?100-v:v; return n<25?C.danger:n<50?C.warning:n<75?C.emerald:C.emeraldDark };
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:6, padding:10, background:'rgba(255,255,255,.78)', backdropFilter:'blur(6px)', borderRadius:10, border:'1px solid rgba(107,74,43,.15)' }}>
      {rows.map(r=>(
        <div key={r.k} style={{ display:'flex', flexDirection:'column', gap:3, alignItems:'center' }}>
          <div style={{ fontSize:14 }}>{r.g}</div>
          <div style={{ fontFamily:"'JetBrains Mono'", fontSize:11, color:C.slateDark }}>{Math.round(metrics[r.k])}</div>
          <div style={{ width:'100%', height:4, background:'#e2e8f0', borderRadius:9999, overflow:'hidden' }}>
            <div style={{ width:`${metrics[r.k]}%`, height:'100%', background:color(metrics[r.k], r.inv), transition:'all .4s' }} />
          </div>
        </div>
      ))}
    </div>
  );
}

function Dossier({ node }) {
  return (
    <div style={{
      position:'absolute', inset:0,
      background:C.paper50,
      backgroundImage:'repeating-linear-gradient(to bottom, transparent 0 22px, rgba(107,74,43,.09) 22px 23px)',
      borderRadius:14, padding:20,
      boxShadow:'0 4px 0 rgba(0,0,0,.05), 0 20px 50px -16px rgba(59,42,26,.55)',
      border:'1px solid rgba(107,74,43,.25)',
      display:'flex', flexDirection:'column', gap:10,
    }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <div>
          <div style={{ fontFamily:"'JetBrains Mono'", fontSize:10, color:C.oak500, letterSpacing:'.08em' }}>
            № {node.NodeID}
          </div>
          <div style={{ fontFamily:'Inter', fontSize:10, fontWeight:700, letterSpacing:'.14em', textTransform:'uppercase', color:C.oak500, marginTop:2 }}>
            Incoming Dossier
          </div>
        </div>
        <div style={{ border:`2px double ${C.wax}`, color:C.wax, padding:'3px 8px', borderRadius:3, fontFamily:"'Special Elite'", fontSize:10, letterSpacing:'.14em', textTransform:'uppercase', transform:'rotate(-4deg)' }}>
          Review
        </div>
      </div>

      <h2 style={{ fontFamily:"'Special Elite'", fontSize:24, margin:0, lineHeight:1.2, color:C.ink900 }}>
        {node.Title}
      </h2>
      <p style={{ fontFamily:"'Libre Caslon Text', serif", fontSize:14.5, lineHeight:1.5, margin:0, color:C.ink900, flex:1 }}>
        {node.Context}
      </p>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, borderTop:'1px dashed rgba(107,74,43,.35)', paddingTop:10 }}>
        <div>
          <div style={{ fontFamily:'Inter', fontSize:9, fontWeight:700, letterSpacing:'.14em', textTransform:'uppercase', color:C.wax }}>◀ Swipe to Deny</div>
          <div style={{ fontFamily:"'Libre Caslon Text', serif", fontSize:13, color:C.ink700, marginTop:3 }}>{node.Choices[1]?.ChoiceText}</div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontFamily:'Inter', fontSize:9, fontWeight:700, letterSpacing:'.14em', textTransform:'uppercase', color:C.emeraldDark }}>Approve ▶</div>
          <div style={{ fontFamily:"'Libre Caslon Text', serif", fontSize:13, color:C.ink700, marginTop:3 }}>{node.Choices[0]?.ChoiceText}</div>
        </div>
      </div>

      {node.Choices[2] && (
        <button className="tap-more" style={{
          background:'transparent', border:'1px solid rgba(107,74,43,.3)',
          padding:'8px 10px', borderRadius:8, fontFamily:'Inter', fontSize:12, fontWeight:600, color:C.ink700, cursor:'pointer',
        }}>Tap for tertiary option — {node.Choices[2].ChoiceText.slice(0,40)}…</button>
      )}
    </div>
  );
}

function SwipeDeck({ nodes, onDecision }) {
  const [idx, setIdx] = useState(0);
  const [dragX, setDragX] = useState(0);
  const startX = useRef(null);

  function onStart(e){ startX.current = (e.touches?.[0]?.clientX) ?? e.clientX }
  function onMove(e){
    if(startX.current==null) return;
    const x = (e.touches?.[0]?.clientX) ?? e.clientX;
    setDragX(x - startX.current);
  }
  function onEnd(){
    if(Math.abs(dragX) > 80){
      const dir = dragX > 0 ? 'right' : 'left';
      onDecision?.(nodes[idx], dir);
      setIdx(i => (i+1) % nodes.length);
    }
    setDragX(0);
    startX.current = null;
  }

  const rotate = dragX / 20;
  const rightTint = Math.min(Math.max(dragX/120, 0), 1);
  const leftTint = Math.min(Math.max(-dragX/120, 0), 1);

  return (
    <div style={{ position:'relative', width:'100%', height:460, perspective:1000 }}>
      {/* Behind card peek */}
      {nodes[(idx+1) % nodes.length] && (
        <div style={{ position:'absolute', inset:'10px 16px 0', transform:'scale(.96)', opacity:.7, filter:'blur(.5px)' }}>
          <Dossier node={nodes[(idx+1) % nodes.length]}/>
        </div>
      )}
      {/* Current */}
      <div
        onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={onEnd}
        onMouseDown={onStart} onMouseMove={(e)=>{ if(startX.current!=null) onMove(e) }} onMouseUp={onEnd} onMouseLeave={()=>{ if(startX.current!=null) onEnd() }}
        style={{
          position:'absolute', inset:0,
          transform:`translateX(${dragX}px) rotate(${rotate}deg)`,
          transition: startX.current==null ? 'transform .3s cubic-bezier(.2,.8,.2,1)' : 'none',
          cursor:'grab', userSelect:'none',
        }}
      >
        <Dossier node={nodes[idx]}/>
        {rightTint > 0.1 && (
          <div style={{ position:'absolute', top:22, left:18, border:`3px double ${C.emeraldDark}`, color:C.emeraldDark, padding:'6px 12px', borderRadius:4, fontFamily:"'Special Elite'", fontSize:16, letterSpacing:'.15em', textTransform:'uppercase', transform:'rotate(-12deg)', opacity:rightTint }}>
            Approve
          </div>
        )}
        {leftTint > 0.1 && (
          <div style={{ position:'absolute', top:22, right:18, border:`3px double ${C.wax}`, color:C.wax, padding:'6px 12px', borderRadius:4, fontFamily:"'Special Elite'", fontSize:16, letterSpacing:'.15em', textTransform:'uppercase', transform:'rotate(10deg)', opacity:leftTint }}>
            Denied
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { MiniHUD, Dossier, SwipeDeck, C });
