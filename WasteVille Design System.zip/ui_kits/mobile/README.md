# Waste Czar Mobile — UI Kit

Phone-sized dossier deck. Each card is a paper document; swipe right to sign/approve, left to deny. Optional third choice surfaces via a tap affordance.

## Components
- `MiniHUD` — compact 5-metric strip with glyphs + bars
- `Dossier` — full-bleed paper card with folder ID, title, context, and swipe-hint footer
- `SwipeDeck` — drag/touch physics, peek of next card, live APPROVE/DENIED seal stamps that fade in as you drag

## Interactions
- Drag > 80px right: approve (choice 0), +metric deltas
- Drag > 80px left: deny (choice 1), −metric deltas
- Tap footer pill: tertiary option (choice 2) — where present
