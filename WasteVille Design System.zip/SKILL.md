---
name: wasteville-design
description: Use this skill to generate well-branded interfaces and assets for WasteVille (the Waste Czar civic-sim), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files — especially `colors_and_type.css` (tokens), `preview/` (small specimen cards), and `ui_kits/desk/` + `ui_kits/mobile/` (full component kits with React/JSX implementations).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. Reuse the tokens in `colors_and_type.css` and the JSX components in `ui_kits/*/components.jsx`.

If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand. The brand is:

- **Visual metaphor:** the Waste Czar's oak desk. Paper dossiers, wax-seal stamps, typewriter titles (Special Elite), serif body (Libre Caslon Text), Inter for UI, JetBrains Mono for codes/metrics.
- **Town canvas:** a 2D isometric grid with pristine↔polluted sprite swaps at `ecoHealth < 35`.
- **Metrics:** five bars — Treasury, EcoHealth, PublicSentiment, InfrastructureLoad (inverted), SocialEquity.
- **Tone:** dry municipal seriousness with a wink. Imperative verbs in choices; aphoristic single-sentence "why it matters" lines in the Action Center.
- **Emoji:** HUD glyphs only; never body copy.
- **Icons:** Lucide CDN (flagged substitution — repo shipped no icon set).

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
