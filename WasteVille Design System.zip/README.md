# WasteVille Design System

> A civic waste-management simulator where the player is appointed **Waste Czar** of a procedurally generated town. Decisions arrive as dossiers on the Czar's desk; three+ meters (Budget / Environment / Public Approval, expanded to five: Treasury, EcoHealth, PublicSentiment, InfrastructureLoad, SocialEquity) respond to every choice.

This design system codifies the visual language of WasteVille: the municipal-dossier metaphor (the Czar's desk, red seal stamps, file folders, ledger paper), the metric HUD, the isometric 2D town with pristine↔polluted sprite swaps, and both the desktop dashboard and the mobile card-swipe interaction model.

---

## Sources

- **Codebase:** `jonathannnty/DataHacks-2026` (imported under `src/`)
  - `src/App.tsx`, `src/features/game/GameScreen.tsx`, `src/features/game/HeadsUpDisplay.tsx`
  - `src/features/story/StoryConsole.tsx` — swipe-to-choose + choice buttons
  - `src/features/action-center/ActionCenter.tsx` + `content/actionCards.ts` — educational endgame
  - `src/features/map/{IsometricMap,GridMap,Tile,Building,CitizenBlob}.tsx` — 2D iso scene
  - `src/game/simulation/*` — five-metric simulation, catastrophe, choice resolution
  - `tailwind.config.js` — `civic-*` color tokens, `blobwalk` / `catastropheShake` keyframes
- **Additional direction from user:** "Waste Czar's office desk" — a person in power; decisions as important documents; immersion into role + gamification mix.

Nothing here assumes the reader has repo access; everything the system needs is copied into this project.

---

## Index (what lives at the root)

| File / Folder | What it is |
|---|---|
| `README.md` | This file — brand context, content & visual foundations, iconography |
| `SKILL.md` | Claude Code-compatible skill entry point for agents |
| `colors_and_type.css` | All color & type CSS variables + semantic element styles |
| `fonts/` | Self-hosted webfonts (currently Google Fonts fallbacks — see Type) |
| `assets/` | Logos, seal, paper textures, icon references, building sprite placeholders |
| `preview/` | Small HTML cards that populate the Design System tab |
| `ui_kits/desk/` | Waste Czar's desk dashboard (desktop) — the core product UI |
| `ui_kits/mobile/` | Tinder-style card-swipe dossier deck (mobile) |
| `src/` | Imported reference source from DataHacks-2026 — read, don't ship |

---

## Content Fundamentals

**Voice: dry municipal seriousness, with a wink.** The product puts the player in a mock position of authority, so copy is written like a real municipal memo — short, declarative, slightly stern — and leans on bureaucratic vocabulary (_ordinance, hauling contract, diversion, siting conflict, airspace, tipping fee_). The humor lives in the gap between the cheerful isometric town and the grim real-world waste policy it's parodying.

**Tense / person:** Third person for scenario context, second person ("you") for direct decision prompts and Action Center checklists. Never first person.

**Casing:**
- **Title Case** for scenario titles ("The Great Overflow", "Pay-As-You-Throw Rollout", "NIMBY Uprising")
- **UPPER CASE** prefix for catastrophes: `CATASTROPHE: Landfill Fire`
- **Sentence case** for body copy, choice buttons, and checklist items
- **UPPERCASE TRACKED** micro-labels ("REAL-WORLD CONTEXT", "WHY IT MATTERS", "PRACTICAL CHECKLIST") — tracked 0.1em, 11px
- **Metric names** are compound-capitalized in data (`EcoHealth`, `PublicSentiment`) but rendered with a space and hyphen in UI (`Eco-Health`, `Infra-Load`).

**Examples from the codebase:**
- Scenario context (short, newspaper-lead style):
  > "It is 2026. WasteVille's historical MSW trendlines show a major rise in food waste and plastics, and the city's only landfill is at 85% capacity. The EPA is knocking and the smell is reaching the suburbs."
- Choice (imperative verb, ends with period):
  > "Launch the Green Mandate with immediate source-reduction policies."
  > "Maintain status quo operations with minor odor controls."
- Action Center — "Why it matters" (1 sentence, aphoristic):
  > "A ton of waste never generated costs nothing to haul, never leaks leachate, and never needs a permit."
- Checklist items (imperative, specific, finishable in a week):
  > "Switch one recurring disposable to a reusable (bottle, bag, coffee cup)."

**Emoji:** Used sparingly and only as **metric glyphs** in the HUD (`$ 🌿 🙂 ⚙ ⚖`) — never in body copy, scenario text, or choice buttons. In the dossier-desk reskin we replace these with engraved stamp glyphs. Unicode symbols like `§`, `№`, `—` (em dash), `•` are part of the paperwork vocabulary and are encouraged.

**Tone tolerances:**
- ✅ "Deferred maintenance is a tax on the future."
- ✅ "NIMBY is often an environmental justice signal."
- ❌ "Yay, you saved the planet! 🌍✨"
- ❌ "Oops, looks like that didn't work out! 😅"

**Numbers & units:** Always concrete. "5.0 lbs of waste per person per day", "85% capacity", "15-30% diversion", "$3-5x contracted rates." Units are spelled out or use standard abbreviations.

---

## Visual Foundations

The visual system has two voices in one product:

1. **The Desk** (chrome): warm, tactile, paper-forward. Oak wood grain, creamy ledger paper, green banker's-lamp glow, red wax-seal stamps, typewriter and serif type. This is where decisions are _read and signed._
2. **The Town** (canvas): cool, saturated, slightly stylized 2D isometric. Emerald grass, sky-blue water, slate roads. When `EcoHealth < 35` the sprites swap to polluted variants (amber/stone/lime-toxic).

The HUD and Action Center sit between the two and inherit from the desk.

### Color

- **Desk neutrals** (primary surface): `--oak-900 #3b2a1a`, `--oak-700 #6b4a2b`, `--paper-50 #f5ecd7` (ledger cream), `--paper-100 #ede1c4`, `--ink-900 #1a1410`.
- **Civic accents** (inherited from codebase Tailwind config):
  - `--emerald #10b981` / `--emerald-dark #047857` — success, "go", healthy metrics, primary CTA.
  - `--slate #334155` / `--slate-dark #0f172a` / `--slate-light #64748b` — body text, map scene background.
  - `--bone #f8fafc` — light surface (used sparingly; most surfaces are paper).
  - `--warning #f59e0b` — threshold crossings, caution stamps.
  - `--danger #ef4444` — catastrophes, failing metrics, `DENIED` seal.
- **Sprite palette (town):**
  - Pristine: emerald-400→600 grass, sky-300→600 water, slate-400→600 roads.
  - Polluted: amber-700/stone-700 grass, lime-500→emerald-800→stone-900 toxic water, amber-700/stone-600 littered roads.

### Type

- **Display / Scenario titles:** **Special Elite** (typewriter). Used for `h1`/`h2` on dossier cards and scenario headlines. It evokes official memos pulled from a drawer. **[SUBSTITUTE: Google Fonts fallback — the repo didn't ship typewriter fonts. Please provide a preferred typewriter face if you have one.]**
- **Serif body / Ledger:** **Libre Caslon Text** — body copy inside dossiers, Action Center prose.
- **Sans UI / HUD:** **Inter** (from the codebase `tailwind.config.js`'s `fontFamily.civic`). Metric labels, buttons, nav, tooltips.
- **Mono / Stamps & codes:** **JetBrains Mono** — scenario IDs (`ROOT_001`), metric values, metadata lines.
- **Scale (px):** 48 display, 32 h1, 24 h2, 18 h3, 16 body, 14 small, 12 micro, 11 tracked-caps.

### Spacing, radii, shadows

- **Space scale:** 4, 8, 12, 16, 24, 32, 48, 64.
- **Radii:** `--r-sm 4px` (buttons, pills), `--r-md 8px` (HUD, choice buttons), `--r-lg 12px` (dossier cards), `--r-xl 16px` (desk panels). Stamps and seals are round (`50%`) or slightly-oval.
- **Shadows:**
  - Paper lift: `0 1px 0 rgba(0,0,0,0.04), 0 10px 24px -12px rgba(59,42,26,0.35)` — dossiers resting on the desk.
  - Embedded/sunken (map well): `inset 0 2px 8px rgba(0,0,0,0.25)`.
  - Hover lift on choice: `translateY(-1px)` + shadow scales ~1.3x.
  - Stamp-on-paper: no shadow; stamps are inked, not floating.

### Backgrounds & surfaces

The **desk background** is a subtle oak grain (CSS gradients + repeating-linear-gradient pattern; no photo needed). **Ledger paper** surfaces use a cream fill with a very faint 24px horizontal rule pattern, like engineering paper. **The map well** is `bg-slate-900/90` with `ring-1 ring-slate-700 shadow-inner` — a screen/monitor embedded into the desk. No photographic textures. No aggressive gradients — the only gradients allowed are the tile sprites themselves and the desk grain.

### Animation & motion

- **Easing:** Framer Motion defaults — `spring` for metric bars (`stiffness: 120, damping: 18`), `linear` for citizen blob hops (they walk on rails). Scenario transitions use a 250ms fade+slide (`y: 8 → 0`).
- **Shake:** `catastropheShake` keyframes from Tailwind config — 3 cycles of sub-3px translate + sub-1° rotate over 500ms. Fires on catastrophe card and on the affected building sprite simultaneously.
- **Blob walk:** `blobwalk` — 3px vertical bob at 1.2s ease-in-out infinite.
- **Hover:** Choice buttons — border color emerald, background → emerald-50, no scale. Primary buttons — background darkens to `emeraldDark`.
- **Press:** `active:scale-[0.99]` on choices; primary buttons flash 50ms darker.
- **Seal stamp** (new for desk reskin): a 120ms `scale: 1.4 → 1` + `rotate: -8deg → 0` when a choice is committed.

### Borders, rings, shadows (component level)

- Most surfaces use `ring-1 ring-slate-200` rather than true borders — keeps edges crisp on retina.
- Catastrophe uses `ring-red-500` + shake.
- Dossier cards: `ring-1` in warm oak tone (`rgba(107,74,43,0.2)`) rather than cool slate.

### Transparency & blur

- HUD strip: `bg-white/70 backdrop-blur` — translucent glass over the desk.
- No blur on dossier body — paperwork reads flat.
- Modals and tooltips may use `backdrop-blur-sm` over the map well.

### Layout rules

- **Desktop:** `max-w-6xl` centered; header top; HUD full-width strip under header; 5-col grid with map (3/5) + dossier console (2/5). HUD is fixed-height (pill strip).
- **Mobile:** Single-column; HUD becomes a 2×3 mini-grid; dossier becomes a tall card deck with swipe.
- **Hit targets** ≥ 44px on touch. Choice buttons are always ≥ 48px tall.

### Cards

- **Dossier card** (scenario console): cream paper background, oak ring, ledger lines, top-left folder tab, 12px radius, generous 20-24px padding. Title in typewriter; body in serif. Choices are outlined bone-colored buttons that hover emerald.
- **Building label** (map): tiny 2px padding pill, `rounded-md`, 10px semibold caps, color shifts by tone (default/warning/danger/success).
- **Action Center card:** same paper surface as dossier, but wider (`max-w-3xl`), with checkbox-list checklist items on bone-colored sub-cards.

### Transitions between scenes

Choice commit → stamp fires → dossier slides out left → next dossier slides in from the manila-folder slot at top of desk. Metric bars animate concurrently. If catastrophe, the whole desk shakes once and the red `CATASTROPHE` seal is stamped onto the incoming card.

---

## Iconography

**Approach:** WasteVille does NOT ship a custom icon set; the codebase uses a mix of Unicode glyphs (`$ ⚙ ⚖`) and single emoji (`🌿 🙂`). The design system's canonical approach:

- **HUD metric glyphs** — keep the codebase's Unicode/emoji set but offer a desk-reskin alternative: small engraved brass stamps for Treasury (coin), EcoHealth (leaf), PublicSentiment (face), InfrastructureLoad (gear), SocialEquity (scales). These are placeholders in `assets/icons/` and can be swapped for real artwork.
- **System icons** (chevron, check, close, filter, pin, stamp, info): use **Lucide** via CDN — `stamp`, `file-text`, `gavel`, `scale`, `coin`, `leaf`, `gauge`, `users`, `flame` (catastrophe), `trending-up`/`trending-down` (metric deltas). Lucide's 2px-stroke, 24px outline style matches the codebase's slate-line weight. **Flagged substitution:** the repo has no icon set, so Lucide is introduced here as the closest-matching default — if you have a preferred set, swap it in.
- **SVG vs PNG:** Lucide icons inline as SVG. Building sprites are PNG-with-transparency per AGENTS.md (`landfill_empty_v1`, `recycling_center_v1`, etc.) — we ship labeled **placeholders** in `assets/sprites/` because real sprite artwork isn't in the repo yet.
- **Emoji:** restricted to metric HUD per above. Not allowed in scenario text, choice buttons, action center prose, or brand surfaces.
- **Unicode chars as icons:** `§` (ordinance), `№` (case number), `—` (em dash), `‡` (footnote), `☑`/`☐` (checklists) — encouraged on dossier paperwork to reinforce municipal vibe.
- **Logo & seal:** `assets/logo-wasteville.svg` (primary wordmark), `assets/seal-czar.svg` (circular "OFFICE OF THE WASTE CZAR" seal), `assets/stamp-approved.svg`, `assets/stamp-denied.svg`, `assets/stamp-catastrophe.svg`.

---

## UI kits

- **`ui_kits/desk/`** — the full Waste Czar's desk dashboard. Desktop-primary. Shows the oak desk, HUD strip, isometric monitor-inlay, dossier folder, and an active scenario card.
- **`ui_kits/mobile/`** — the card-swipe dossier deck for phones. Swipe left to deny, right to approve, optional tap to expand the dossier for the tertiary choice.

Each kit's `index.html` is a click-through mini-prototype that demonstrates real interactions (pick a choice, watch the metrics animate, stamp the paper).

---

## Caveats (read me)

- **Font substitutions:** Special Elite + Libre Caslon Text are Google Fonts stand-ins for a typewriter+ledger pair. If you have licensed fonts you prefer, drop `.woff2` files into `fonts/` and update `colors_and_type.css`.
- **Icons:** Lucide is the placeholder system; swap if needed.
- **Sprites:** Isometric building PNGs are labeled placeholders — real artwork is out of scope for the design system.
- **Desk photography vs. CSS:** the desk surfaces are built from CSS gradients, not photographs. A textured wood photograph would push the aesthetic further if you want it.
